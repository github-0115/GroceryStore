# ECharts Map Tool

A tool to generate China local geographic map data.
