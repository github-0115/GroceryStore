
**Make world GeoJSON**

+ Parse shp file (download from naturalearth) to json.
+ Edit boundary (generate `raw/world-fixed.json`).
+ Post process using `postprocess.js`.

In mobile, simplify it using mapshaper (generate `raw/world-fixed-simp.json`).
