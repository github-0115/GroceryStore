cp ../js/world.js ../../../echarts/map/js/
cp ../json/world.json ../../../echarts/map/json/

ls -alF ../../../echarts/map/json/world.json
ls -alF ../../../echarts/map/js/world.js